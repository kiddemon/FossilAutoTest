/*Why is the order of outputs in 2 and 1 different?: b/c it's running without synchronized method is used to lock an object for any shared resource.*/

public class CarQuestion4 implements Runnable{
    int wheel = 4;
    int doors = 4;
    int seats = 5;
    int max_speed;
    public synchronized void run(){
    }

    public void info(){
        System.out.println("wheel equal " + wheel);
        System.out.println("doors equal " + doors);
        System.out.println("seats equal " + seats);
        System.out.println("Max speed equal " + max_speed);
    }

    public static void main(String args[]){
        CarQuestion4 carQuestion4 = new CarQuestion4();
        ThreadedSend1 t1 = new ThreadedSend1(100, carQuestion4);
        ThreadedSend1 t2 = new ThreadedSend1(200, carQuestion4);
        t1.start();
        t2.start();
    }
}

class ThreadedSend1 extends Thread
{
    int max_speed;
    CarQuestion4  sender;

    ThreadedSend1(int maxspeed, CarQuestion4 obj)
    {
        max_speed = maxspeed;
        sender = obj;
    }

    public void run()
    {
        synchronized(sender)
        {
            for(int i =0; i< 10; i++){
                System.out.println("Max speed equal " + max_speed);
            }

        }
    }
}

